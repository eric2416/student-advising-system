Current Active Accounts:
	STUDENT:
	Username - student
	Password - pass
	
	ADVISOR:
	Username - advisor
	Password - pass


Account Database Structure:
	STUDENTS:
	NAME (TEXT)
	ID (INT) UNIQUE
	Username (TEXT) UNIQUE
	Password (TEXT) STRICT
	MAJOR (TEXT)
	COURSES (TEXT)

	ADVISORS:
	NAME (TEXT)
	ID (INT) UNIQUE
	Username (TEXT) UNIQUE
	Password (TEXT) STRICT
	EMAIL (TEXT)
	PHONE (TEXT)

Course Database Structure:
	ID (TEXT)
	Section (INTEGER)
	Name (TEXT)
	Instructor (TEXT)
	Day 1 (TEXT)
	Day 2 (TEXT)
	Time (DOUBLE)
	Length (DOUBLE)
	Location (TEXT)
	
	
To do:
	All of the classes under "classes"
	Appearance
	Interfaces for:
		Advisor
			Advisor itself
			All Advisor Sub Functions
		Student
			Student itself
			All Student Sub Functions

Done:
	Created account database
	Created course database
	Connected databases
	Created login, student, catalog interface
	Successful account logins based on user type
	Displays the whole course catalog