Current Active Accounts:
	Username - admin
	Password - admin
		This is currently seen as a student account

Account Database Structure:
	Name (TEXT)
	ID (INTEGER)
	Username (TEXT)
	Password (TEXT)
	Courses (TEXT)
	Major (TEXT)
	Type (TEXT)

Course Database Structure:
	CourseID (TEXT)
	Section (INTEGER)
	Instructor (TEXT)
	Time (TEXT)
	Location (TEXT)
	
	
To do:
	All of the classes under "classes"
	Figure out how to verify if a login is a student or if it is something else
	Appearance
	Interfaces for:
		Advisor
			Advisor itself
			All Advisor Sub Functions
		Student
			Student itself
			All Student Sub Functions