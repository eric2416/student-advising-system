
public class Main {
	
	//Holds the ID of the current active user
		//Allows for user specific information to be retrieved and stored
	public int loginID;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
