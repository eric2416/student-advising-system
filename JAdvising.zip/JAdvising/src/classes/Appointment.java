package classes;

public class Appointment {
	//No functions were defined in 1.2 Class Diagram
	
	//Date, Time
}
