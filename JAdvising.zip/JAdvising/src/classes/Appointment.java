package classes;

public class Appointment {
	//No functions were defined in 1.2 Class Diagram
	
	//Date, Time
	
	public void requestAppointment() {
		//Pre Conditions:
			//Student must know which class to request an appointment with. Either ITS or Advisor
			//Student must know date and time they want to request the appointment
			//Class receiving the appointment request must be free during request time
		//Post Conditions:
			//ITS or Advisor accepts appointment
			//ITS or Advisor reschedules appointment
	}
}
