package classes;

public class StudentAccount {
	//combined with student account
	public static String name;
	public static Integer id;
	public static String[] courses;
	public static String major;
	
	
	public void displayCourse() {
		
	}
	
	public void getStudent() {
		
	}
}
