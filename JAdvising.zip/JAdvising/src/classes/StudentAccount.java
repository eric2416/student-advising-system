package classes;

public class StudentAccount {
	//combined with student account
	public static String name;
	public static Integer id;
	public static String[] courses = new String[10];
	public static String[] taken = new String[100];
	public static Integer credits;
	public static String major;
	public static String username;
	public static String coursesStr;
	
	public void displayCourse() {
		
	}
	
	public void getStudent() {
		
	}
}
