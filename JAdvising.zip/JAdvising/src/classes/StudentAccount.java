package classes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

import javax.swing.JOptionPane;

public class StudentAccount {
	//combined with student account
	public static String name;
	public static Integer id;
	public static String[] taken = new String[100];
	public static Integer credits;
	public static String major;
	public static String username;
	public static String coursesStr;
	public static ArrayList<String> courses = new ArrayList<String>();
	public static ArrayList<String> taken1 = new ArrayList<String>(); //have to implement this later
	
	public void displayCourse() {
		
	}
	
	public void getStudent() {
		
	}
	
	public static void updateStudentAccountInfo(String id) {
		courses.add(id);
	}
}
