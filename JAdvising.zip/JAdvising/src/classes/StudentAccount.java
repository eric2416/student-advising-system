package classes;

public class StudentAccount {
	//combined with student account
	public static String name;
	public static Integer id;
	public static String[] courses = new String[6];
	public static String major;
	public static String username;
	
	public void displayCourse() {
		
	}
	
	public void getStudent() {
		
	}
}
