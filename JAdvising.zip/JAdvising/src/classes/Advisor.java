package classes;

public class Advisor {
	//No functions were defined in 1.2 Class Diagram
	
	//Name, Address, Email, Phone Number, Department
}
