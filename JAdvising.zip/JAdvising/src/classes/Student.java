package classes;

public class Student {
	//combined with student account
	//student name, id, list of courses, department
	
	public void displayCourse() {
		
	}
	
	public void getStudent() {
		
	}
}
