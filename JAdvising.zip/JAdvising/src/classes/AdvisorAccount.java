package classes;

public class AdvisorAccount {
	//No functions were defined in 1.2 Class Diagram
	public static String name;
	public static String address;
	public static String email;
	public static String phone;
	public static String department;
	//Name, Address, Email, Phone Number, Department
}
