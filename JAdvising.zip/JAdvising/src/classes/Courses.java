package classes;

public class Courses {
	//No functions were defined in 1.2 Class Diagram
	
	//name, section number, instruction, time
	public void addClass() {
		//Pre Conditions:
			//Student must qualify for said class. So freshmans cant register for junior level
			//courses
			//If added, the class cannot exceed the max number of credits student can take. In
			//most cases 19
			//Class must still have spots left open
		//Post Conditions:
			//Student successfully registers for course
	}
	
	public void dropClass() {
		//Pre Conditions:
			//If dropped, the students total number of credit hours cannot be below 12
		//Post Conditions:
			//ITS	or	Advisor accepts	appointment
	}
}
