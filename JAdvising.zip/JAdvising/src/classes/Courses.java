package classes;

public class Courses {
	//No functions were defined in 1.2 Class Diagram
	
	//name, section number, instruction, time
}
