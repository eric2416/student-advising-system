package classes;

import javax.swing.JOptionPane;

import data.readDatabase;

public class Courses {
	//No functions were defined in 1.2 Class Diagram
	
	//name, section number, instruction, time
	public static void addClass(String id) {
		//Pre Conditions:
			//Student must qualify for said class. So freshmans cant register for junior level
			//courses
			//If added, the class cannot exceed the max number of credits student can take. In
			//most cases 19
			//Class must still have spots left open
		//Post Conditions:
			//Student successfully registers for course
		if(readDatabase.classStatus(id)) {
			JOptionPane.showMessageDialog(null, readDatabase.classStatus(id));
			if(readDatabase.prereqsMet(id)) {
				
			}
		}
	}
	
	public void dropClass(String ID) {
		//Pre Conditions:
			//If dropped, the students total number of credit hours cannot be below 12
		//Post Conditions:
			//ITS	or	Advisor accepts	appointment
	}
}
