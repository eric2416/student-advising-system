package classes;

import java.util.Arrays;
import java.util.LinkedList;

import javax.swing.JOptionPane;

import data.editDatabase;
import data.readDatabase;

public class Courses {
	//No functions were defined in 1.2 Class Diagram
	public static int credits;
	
	//name, section number, instruction, time
	public static void addClass(String id) {
		//Pre Conditions:
			//Student must qualify for said class. So freshmans cant register for junior level
			//courses
			//If added, the class cannot exceed the max number of credits student can take. In
			//most cases 19
			//Class must still have spots left open
		//Post Conditions:
			//Student successfully registers for course

		//LinkedList currentCourses = new LinkedList(Arrays.asList(StudentAccount.courses));
		
		JOptionPane.showMessageDialog(null, "class status is " + readDatabase.classStatus(id));
		if(!StudentAccount.courses.contains(id)) {
			if(readDatabase.classStatus(id)) {
				JOptionPane.showMessageDialog(null, "prereqs is " + readDatabase.prereqsMet(id));
				if(readDatabase.prereqsMet(id)) {
					JOptionPane.showMessageDialog(null, "credits is " + readDatabase.checkCredits(id));
					if(readDatabase.checkCredits(id)) {
						JOptionPane.showMessageDialog(null, "You can enroll in " + id);
						editDatabase.enrollStudent(id);
						StudentAccount.updateStudentAccountInfo(id);
					}
					else {
						JOptionPane.showMessageDialog(null, "You cannot earn more than 19 credits per semester");
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "You do not meet the prereqs");
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "The class is full");
			}
		}
		else {
			JOptionPane.showMessageDialog(null, "You are already enrolled in " + id);
		}
	}
	
	
	
	public void dropClass(String ID) {
		//Pre Conditions:
			//If dropped, the students total number of credit hours cannot be below 12
		//Post Conditions:
			//ITS	or	Advisor accepts	appointment
	}
}
