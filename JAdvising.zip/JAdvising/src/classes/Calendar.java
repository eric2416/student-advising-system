package classes;

public class Calendar {
	
	//date, time
	
	
	public void displayTime() {
		
	}
	
	public void displayDate() {
		
	}
	
	public void recordTime() {
		
	}
	
	public void recordDate() {
		
	}
}
