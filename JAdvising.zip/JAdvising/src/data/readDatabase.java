package data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import frames.Student;

/*
 * readDatabase allows us the access information from the database connection
 * that is provided.
 */
public class readDatabase {
	
	public static void verifyLogin(String fldUsername, String fldPassword, JFrame frame) {
		try {
			//Create a query for the username and password
			String query = " select * from accounts where username=? and password=? ";
			//Create a PreparedStatement so we can receive data from the database
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setString(1, fldUsername);
			pst.setString(2,  fldPassword);
			
			//Set of all the information in the database
			ResultSet rs = pst.executeQuery();
			
			//Count the occurences of username and password on the same row
			int count = 0;
			while(rs.next()) {
				count++;
			}
			
			//Information provided is valid
			if(count == 1) {
				//Removes the login frame
				frame.dispose();
				
				//IF STUDENT LOGIN
					//Display the student page
					Student stdnt = new Student();
					stdnt.setVisible(true);
				//IF ADVISOR LOGIN
					//Display the advisor page
					//Advisor adv = new Advisor();
					//adv.setVisible(true);
			}
			//Multiple of the same account exists in the database
			else if (count > 1) {
				JOptionPane.showMessageDialog(null, "Duplicate Username and Password");
			}
			//User does not exist in the database or password is incorrect
			else {
				JOptionPane.showMessageDialog(null, "Username and/or Password is not correct");
			}
			
			//Close the data reception from the database
			rs.close();
			pst.close();
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
}
