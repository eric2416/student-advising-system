package data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import classes.AdvisorAccount;
import classes.Courses;
import classes.StudentAccount;
import frames.Advisor;
import frames.Catalog;
import frames.Schedule;
import frames.Student;
import net.proteanit.sql.DbUtils;

/*
 * readDatabase allows us the access information from the database connection
 * that is provided.
 */
public class readDatabase {
	
	public static void verifyLoginStudent(String username, String password, JFrame frame) {
		try {
			//Create a query for the username and password
			String query = " select * from students where username=? and password=? ";
			//Create a PreparedStatement so we can receive data from the database
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setString(1, username);
			pst.setString(2,  password);
			
			//Set of all the information in the database
			ResultSet rs = pst.executeQuery();
			
			//Count the occurences of username and password on the same row
			int count = 0;
			while(rs.next()) {
				count++;
			}
			
			//Information provided is valid
			if(count == 1) {
				//Removes the login frame
				frame.dispose();
				
				//Reads the database to find out various info about the student
				studentInfo(username);
				
				//Display the student frame
				Student stdnt = new Student();
				stdnt.setVisible(true);
			}
			//Multiple of the same account exists in the database
			else if (count > 1) {
				JOptionPane.showMessageDialog(null, "Duplicate Username and Password");
			}
			//User does not exist in the database or password is incorrect
			else {
				JOptionPane.showMessageDialog(null, "Username and/or Password is not correct");
			}
			
			//Close the data reception from the database
			rs.close();
			pst.close();
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	
	
	public static void verifyLoginAdvisor(String username, String password, JFrame frame) {
		try {
			//Create a query for the username and password
			String query = " select * from advisors where username=? and password=? ";
			//Create a PreparedStatement so we can receive data from the database
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setString(1, username);
			pst.setString(2,  password);
			
			//Set of all the information in the database
			ResultSet rs = pst.executeQuery();
			
			//Count the occurences of username and password on the same row
			int count = 0;
			while(rs.next()) {
				count++;
			}
			
			//Information provided is valid
			if(count == 1) {
				//Removes the login frame
				frame.dispose();
				
				//Reads the database to find out various info about the advisor
				advisorInfo(username);
				
				//Display the advisor frame
				Advisor adv = new Advisor();
				adv.setVisible(true);
			}
			//Multiple of the same account exists in the database
			else if (count > 1) {
				JOptionPane.showMessageDialog(null, "Duplicate Username and Password");
			}
			//User does not exist in the database or password is incorrect
			else {
				JOptionPane.showMessageDialog(null, "Username and/or Password is not correct");
			}
			//Close the data reception from the database
			rs.close();
			pst.close();
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	
	
	public static void studentInfo(String username) {
		//These have to be adjusted based on the username!
		StudentAccount.username = username;
		
		try {
			String query = " select * from students where username=?";
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				StudentAccount.name = rs.getString("name");
				StudentAccount.id = rs.getInt("id");
				StudentAccount.major = rs.getString("major");
				StudentAccount.coursesStr = rs.getString("courses");
				String holder = rs.getString("courses").replaceAll("\\s", "");
				String[] holderArr = holder.split(",");	
				holder = rs.getString("taken").replaceAll("\\s", "");
				StudentAccount.taken = holder.split(",");
				StudentAccount.credits = rs.getInt("credits");
				for(int i=0; i<holderArr.length; i++) {
					StudentAccount.courses.add(holderArr[i]);
				}
			}
			
			rs.close();
			pst.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	
	
	public static void advisorInfo(String username) {
		try {
			String query = "select * from advisors where username=?";
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				AdvisorAccount.name = rs.getString("name");
				AdvisorAccount.address = rs.getString("address");
				AdvisorAccount.email = rs.getString("email");
				AdvisorAccount.phone = rs.getString("phone");
				AdvisorAccount.department = rs.getString("department");
			}
			
			rs.close();
			pst.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	
	
	public static void populateCourses() {
		try {
			String query = "select * from courses";
			PreparedStatement pst = sqliteConnection.connCourse.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			Catalog.table.setModel(DbUtils.resultSetToTableModel(rs));
			rs.close();
			pst.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public static void populateStudents() {
		try {
			String query = "select * from students";
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			Catalog.table.setModel(DbUtils.resultSetToTableModel(rs)); //CHANGE CATALOG
			rs.close();
			pst.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public static void populateCourseSchedule() {
		try {
			StringBuilder queryBuilder = new StringBuilder("select * from courses where");
			for(int i=0; i < StudentAccount.courses.size(); i++) {
			    queryBuilder.append(" id = ? OR");
			}

			// remove the final " OR" from the query at the end
			queryBuilder.replace(queryBuilder.length() - 3, queryBuilder.length(), "");
			
			PreparedStatement pst = sqliteConnection.connCourse.prepareStatement(queryBuilder.toString());
			for(int i = 1; i <= StudentAccount.courses.size(); i++) {
				pst.setString(i, StudentAccount.courses.get(i-1));
			}
			ResultSet rs = pst.executeQuery();
			Schedule.table.setModel(DbUtils.resultSetToTableModel(rs));
			rs.close();
			pst.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public static boolean classStatus (String id) {
		try {
			String query = "select * from courses where id=?";
			PreparedStatement pst = sqliteConnection.connCourse.prepareStatement(query);
			pst.setString(1, id);
			ResultSet rs = pst.executeQuery();
		
			while(rs.next()) {
				if(rs.getBoolean("Open")) {
					Courses.currentPopulation = rs.getInt("current");
					Courses.maxPopulation = rs.getInt("max");
					rs.close();
					pst.close();
					return true;
				}
			}
			rs.close();
			pst.close();
			return false;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return false;
		}
	}
	
	public static boolean prereqsMet (String id) {
		try {
			String query = "select * from courses where id=?";
			PreparedStatement pst = sqliteConnection.connCourse.prepareStatement(query);
			pst.setString(1, id);
			ResultSet rs = pst.executeQuery();
		
			while(rs.next()) {
				JOptionPane.showMessageDialog(null, rs.getString("prereq"));
				if(rs.getString("prereq").equals("")) {
					return true;
				}
				
				String holder = rs.getString("prereq").replaceAll("\\s", "");
				LinkedList reqs = new LinkedList(Arrays.asList(holder.split(",")));
				
				//HAVE TO EDIT THIS, WILL ONLY WORK IF REQS == TAKEN
				for(int i=0; i < StudentAccount.taken.length; i++) {
					if(!reqs.contains(StudentAccount.taken[i])) {
						rs.close();
						pst.close();
						return false;
					}
				}
			}
			rs.close();
			pst.close();
			return true;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return false;
		}
	}
	
	public static boolean checkCredits (String id) {
		try {
			String query = "select * from courses where id=?";
			PreparedStatement pst = sqliteConnection.connCourse.prepareStatement(query);
			pst.setString(1, id);
			ResultSet rs = pst.executeQuery();
		
			while(rs.next()) {
				Courses.credits = rs.getInt("credits");
				if(StudentAccount.credits + Courses.credits <= 19) {
					rs.close();
					pst.close();
					return true;
				}
			}
			rs.close();
			pst.close();
			return false;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return false;
		}
	}
	
	public static boolean minCredits (String id) {
		try {
			String query = "select * from courses where id=?";
			PreparedStatement pst = sqliteConnection.connCourse.prepareStatement(query);
			pst.setString(1, id);
			ResultSet rs = pst.executeQuery();
		
			while(rs.next()) {
				Courses.credits = rs.getInt("credits");
				if(StudentAccount.credits - Courses.credits >= 12) {
					rs.close();
					pst.close();
					return true;
				}
			}
			rs.close();
			pst.close();
			return false;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return false;
		}
	}
}
