package data;

import java.sql.*;
import javax.swing.*;

/*
 * sqliteConnection allows us to get access to various database that the user is
 * trying to connect to.
 * 
 * Once connected, the database can be read and modified based on user interactions wit
 * the software.
 */
public class sqliteConnection {
	public static Connection connAccount = null;
	public static Connection connCourse = null;
	
	//Connects the software to the account database
	public static Connection accountConnector() {
		try {
			Class.forName("org.sqlite.JDBC");
			//Create a Connection to the account database
			connAccount = DriverManager.getConnection("jdbc:sqlite:resources//databases//accounts.sqlite");
			//Display a message notifying the user that they connected successfully
			JOptionPane.showMessageDialog(null, "Database Connection Successfull");
			//Return the Connection
			return connAccount;
		} catch(Exception e) {
			//Connection to the database was unsuccessful, display the error message
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
	}
	
	//Connects the software to the course database
	public static Connection courseConnector() {
		try {
			Class.forName("org.sqlite.JDBC");
			//Create a Connection to the account database
			Connection conn = DriverManager.getConnection("jdbc:sqlite:resources//databases//courses.sqlite");
			//Display a message notifying the user that they connected successfully
			JOptionPane.showMessageDialog(null, "Database Connection Successfull");
			//Return the Connection
			return conn;
		} catch(Exception e) {
			//Connection to the database was unsuccessful, display the error message
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
	}
}
