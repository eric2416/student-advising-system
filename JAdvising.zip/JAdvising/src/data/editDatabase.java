package data;

public class editDatabase {
	public static void enrollStudent(String id) {
		//change students list of courses
		//change students credits
		//change the courses enrollment total
			//if enrollment is == max, change the open to 0
		
		//String query = "UPDATE students set "
	}
}
