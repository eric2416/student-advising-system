package data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

import classes.Courses;
import classes.StudentAccount;

public class editDatabase {
	public static void enrollStudent(String id) {			
		updateCredits(id);
		updateCurrentCourses(id);
		updateCoursePopulation(id);
	}
	
	//works
	public static void updateCredits(String id) {
		try {
			String query = "UPDATE students SET credits = ? + credits WHERE name = ?";
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setInt(1, Courses.credits);
			pst.setString(2, StudentAccount.name);
			int update = pst.executeUpdate();
			if (update > 0) {
				JOptionPane.showMessageDialog(null, "UPDATED!");
			}
			pst.close();
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	//works
	public static void updateCurrentCourses(String id) {
		try {
			String query = "UPDATE students SET courses = ?  WHERE name = ?";
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setString(1, StudentAccount.coursesStr + ", " + StudentAccount.courses.get(StudentAccount.courses.size()-1));
			pst.setString(2, StudentAccount.name);
			int update = pst.executeUpdate();
			if (update > 0) {
				JOptionPane.showMessageDialog(null, "UPDATED!");
			}
			pst.close();
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	//works
	public static void updateCoursePopulation(String id) {
		try {
			String query = "UPDATE courses SET current = current + 1  WHERE id = ?";
			PreparedStatement pst = sqliteConnection.connCourse.prepareStatement(query);
			pst.setString(1, id);
			int update = pst.executeUpdate();
			if (update > 0) {
				JOptionPane.showMessageDialog(null, "UPDATED!");
			}
			pst.close();
			readDatabase.populateCourseSchedule();

			if(Courses.currentPopulation + 1 >= Courses.maxPopulation) {
				fullCourse(id);
			}
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	//works
	public static void fullCourse(String id) {
		try {
			String query = "UPDATE courses SET open = 0  WHERE id = ?";
			PreparedStatement pst = sqliteConnection.connCourse.prepareStatement(query);
			pst.setString(1, id);
			int update = pst.executeUpdate();
			if (update > 0) {
				JOptionPane.showMessageDialog(null, "UPDATED!");
			}
			pst.close();
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public static void changePassword(String pwd) {
		try {
			String query = "UPDATE students SET password = ?  WHERE username = ?";
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setString(1, pwd);
			pst.setString(2, StudentAccount.username);
			int update = pst.executeUpdate();
			if (update > 0) {
				JOptionPane.showMessageDialog(null, "UPDATED!");
			}
			pst.close();
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public static void dropClass(String id) {
	
	}
}