package data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

import classes.Courses;
import classes.StudentAccount;

public class editDatabase {
	public static void enrollStudent(String id) {
		//change students list of courses
		//change students credits
		//change the courses enrollment total
			//if enrollment is == max, change the open to 0
		try {
			String query = "UPDATE students SET credits = ? + credits WHERE name = ?";
			PreparedStatement pst = sqliteConnection.connAccount.prepareStatement(query);
			pst.setInt(1, Courses.credits);
			pst.setString(2, StudentAccount.name);
			int update = pst.executeUpdate();
			if (update > 0) {
				JOptionPane.showMessageDialog(null, "UPDATED!");
			}
			pst.close();
		} catch(Exception e) {
			//e
		}
		
		//HAVE TO UPDATE CURRENT CLASSES BEING TAKEN, HAVE TO UPDATE STUDENTACCOUNT COURSES
		
	}
}
