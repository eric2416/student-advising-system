package data;

public class currentLogin {
	public static String type;
}
