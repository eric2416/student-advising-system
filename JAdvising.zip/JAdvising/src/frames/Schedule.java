package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import classes.Courses;
import classes.StudentAccount;
import data.editDatabase;
import data.readDatabase;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Schedule extends JFrame {

	private JPanel contentPane;
	public static JTable table;
	private JLabel lblEasyCurretlyImplementing;
	private JButton btnNewButton;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Schedule frame = new Schedule();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Schedule() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1001, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCurrentlyEnrolled = new JLabel("Currently Enrolled");
		lblCurrentlyEnrolled.setBounds(81, 87, 128, 20);
		contentPane.add(lblCurrentlyEnrolled);
		
		table = new JTable();
		table.setBounds(45, 159, 908, 356);
		contentPane.add(table);
		
		lblEasyCurretlyImplementing = new JLabel("Done, just have to make it look clean now. Ez");
		lblEasyCurretlyImplementing.setBounds(70, 33, 621, 20);
		contentPane.add(lblEasyCurretlyImplementing);
		
		JLabel lblNewLabel = new JLabel("aa");
		lblNewLabel.setBounds(242, 87, 359, 20);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(623, 113, 100, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		btnNewButton = new JButton("Drop");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(StudentAccount.courses.contains(textField.getText())){
					Courses.dropClass(textField.getText());
				}
			}
		});
		btnNewButton.setBounds(738, 113, 200, 30);
		contentPane.add(btnNewButton);
		
		JLabel lblId = new JLabel("ID");
		lblId.setBounds(654, 87, 69, 20);
		contentPane.add(lblId);
	}
}
