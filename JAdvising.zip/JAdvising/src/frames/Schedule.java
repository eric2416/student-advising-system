package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import classes.StudentAccount;
import data.readDatabase;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Schedule extends JFrame {

	private JPanel contentPane;
	public static JTable table;
	private JLabel lblEasyCurretlyImplementing;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Schedule frame = new Schedule();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Schedule() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1001, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCurrentlyEnrolled = new JLabel("Currently Enrolled");
		lblCurrentlyEnrolled.setBounds(361, 87, 128, 20);
		contentPane.add(lblCurrentlyEnrolled);
		
		table = new JTable();
		table.setBounds(45, 207, 908, 318);
		contentPane.add(table);
		
		lblEasyCurretlyImplementing = new JLabel("Done, just have to make it look clean now. Ez");
		lblEasyCurretlyImplementing.setBounds(70, 33, 621, 20);
		contentPane.add(lblEasyCurretlyImplementing);
		
		JLabel lblNewLabel = new JLabel("aa");
		lblNewLabel.setBounds(504, 87, 449, 20);
		contentPane.add(lblNewLabel);
	}
}
