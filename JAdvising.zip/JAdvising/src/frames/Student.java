package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import classes.StudentAccount;
import data.readDatabase;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

public class Student extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student frame = new Student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 250);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(20, 20, 20));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Catalog ctlg = new Catalog();
		JButton btnCourseCatalog = new JButton("Course Catalog");
		btnCourseCatalog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!ctlg.isVisible()) {
					ctlg.setVisible(true);
				}
			}
		});
		btnCourseCatalog.setBounds(15, 164, 150, 30);
		contentPane.add(btnCourseCatalog);
		
		Schedule schdle = new Schedule();
		JButton btnSchedule = new JButton("Schedule");
		btnSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!schdle.isVisible()) {
					schdle.setVisible(true);
				}
			}
		});
		btnSchedule.setBounds(180, 164, 150, 30);
		contentPane.add(btnSchedule);
		
		ManageAccount mngAcc = new ManageAccount();
		JButton btnManageAccount = new JButton("Manage Account");
		btnManageAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!mngAcc.isVisible()) {
					mngAcc.setVisible(true);
				}
			}
		});
		btnManageAccount.setBounds(364, 164, 150, 30);
		contentPane.add(btnManageAccount);
		
		JLabel lblName = new JLabel(StudentAccount.name);
		lblName.setForeground(new Color (255, 140, 35));
		lblName.setFont(new Font("MV Boli", Font.PLAIN, 20));
		lblName.setHorizontalAlignment(SwingConstants.CENTER);
		lblName.setBounds(15, 58, 664, 20);
		contentPane.add(lblName);
		
		JLabel lblID = new JLabel(String.valueOf(StudentAccount.id));
		lblID.setForeground(new Color (255, 140, 35));
		lblID.setFont(new Font("MV Boli", Font.PLAIN, 12));
		lblID.setHorizontalAlignment(SwingConstants.CENTER);
		lblID.setBounds(15, 86, 664, 20);
		contentPane.add(lblID);
		
		AdvisingAppointment advAptmnt = new AdvisingAppointment();
		JButton btnAdvisorAppointment = new JButton("Advising");
		btnAdvisorAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!advAptmnt.isVisible()) {
					advAptmnt.setVisible(true);
				}
			}
		});
		btnAdvisorAppointment.setBounds(529, 164, 150, 30);
		contentPane.add(btnAdvisorAppointment);
		
		JLabel lblWelcome = new JLabel("Welcome");
		lblWelcome.setForeground(new Color (255, 140, 35));
		lblWelcome.setFont(new Font("MV Boli", Font.PLAIN, 22));
		lblWelcome.setHorizontalAlignment(SwingConstants.CENTER);
		lblWelcome.setBounds(15, 29, 664, 20);
		contentPane.add(lblWelcome);
		
		for(int i = 0; i < StudentAccount.courses.length; i++) {
			JOptionPane.showMessageDialog(null, StudentAccount.courses[i]);
		}
		readDatabase.populateCourseSchedule();
	}
}
