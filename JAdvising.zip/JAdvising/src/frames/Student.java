package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Student extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student frame = new Student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 451);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCourseCatalog = new JButton("Course Catalog");
		btnCourseCatalog.setBounds(247, 122, 200, 30);
		contentPane.add(btnCourseCatalog);
		
		JButton btnSchedule = new JButton("Schedule");
		btnSchedule.setBounds(247, 192, 200, 30);
		contentPane.add(btnSchedule);
		
		JButton btnManageAccount = new JButton("Manage Account");
		btnManageAccount.setBounds(247, 297, 200, 30);
		contentPane.add(btnManageAccount);
	}

}
