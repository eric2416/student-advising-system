package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import classes.StudentAccount;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class Student extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student frame = new Student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCourseCatalog = new JButton("Course Catalog");
		btnCourseCatalog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Catalog ctlg = new Catalog();
				ctlg.setVisible(true);
			}
		});
		btnCourseCatalog.setBounds(247, 122, 200, 30);
		contentPane.add(btnCourseCatalog);
		
		JButton btnSchedule = new JButton("Schedule");
		btnSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Schedule schdle = new Schedule();
				schdle.setVisible(true);
			}
		});
		btnSchedule.setBounds(247, 192, 200, 30);
		contentPane.add(btnSchedule);
		
		JButton btnManageAccount = new JButton("Manage Account");
		btnManageAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageAccount mngAcc = new ManageAccount();
				mngAcc.setVisible(true);
			}
		});
		btnManageAccount.setBounds(247, 262, 200, 30);
		contentPane.add(btnManageAccount);
		
		JLabel lblNewLabel = new JLabel(StudentAccount.username);
		lblNewLabel.setBounds(59, 60, 69, 20);
		contentPane.add(lblNewLabel);
	}

}
