package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import classes.StudentAccount;
import data.readDatabase;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Student extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student frame = new Student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Catalog ctlg = new Catalog();
		JButton btnCourseCatalog = new JButton("Course Catalog");
		btnCourseCatalog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!ctlg.isVisible()) {
					ctlg.setVisible(true);
				}
			}
		});
		btnCourseCatalog.setBounds(247, 122, 200, 30);
		contentPane.add(btnCourseCatalog);
		
		Schedule schdle = new Schedule();
		JButton btnSchedule = new JButton("Schedule");
		btnSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!schdle.isVisible()) {
					schdle.setVisible(true);
				}
			}
		});
		btnSchedule.setBounds(247, 192, 200, 30);
		contentPane.add(btnSchedule);
		
		ManageAccount mngAcc = new ManageAccount();
		JButton btnManageAccount = new JButton("Manage Account");
		btnManageAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!mngAcc.isVisible()) {
					mngAcc.setVisible(true);
				}
			}
		});
		btnManageAccount.setBounds(247, 265, 200, 30);
		contentPane.add(btnManageAccount);
		
		JLabel lblName = new JLabel(StudentAccount.name);
		lblName.setBounds(45, 34, 69, 20);
		contentPane.add(lblName);
		
		JLabel lblID = new JLabel(String.valueOf(StudentAccount.id));
		lblID.setBounds(55, 70, 69, 20);
		contentPane.add(lblID);
		
		JLabel lblMajor = new JLabel(StudentAccount.major);
		lblMajor.setBounds(55, 127, 69, 20);
		contentPane.add(lblMajor);
		
		AdvisingAppointment advAptmnt = new AdvisingAppointment();
		JButton btnAdvisorAppointment = new JButton("Advisor Appointment");
		btnAdvisorAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!advAptmnt.isVisible()) {
					advAptmnt.setVisible(true);
				}
			}
		});
		btnAdvisorAppointment.setBounds(247, 331, 200, 30);
		contentPane.add(btnAdvisorAppointment);
		
		for(int i = 0; i < StudentAccount.courses.length; i++) {
			JOptionPane.showMessageDialog(null, StudentAccount.courses[i]);
		}
		readDatabase.populateCourseSchedule();
	}
}
