package frames;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import data.readDatabase;
import data.sqliteConnection;
import javax.swing.JPasswordField;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JCheckBox;

public class Login {
	private JFrame frame;
	private JTextField fldUsername;
	private JPasswordField fldPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
		sqliteConnection.accountConnector();
		sqliteConnection.courseConnector();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(20, 20, 20));
		frame.setResizable(false);
		frame.setBounds(100, 100, 700, 376);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setForeground(new Color(255, 140, 35));
		lblNewLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel.setBounds(160, 165, 79, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setForeground(new Color(255, 140, 35));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel_1.setBounds(160, 209, 79, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		fldUsername = new JTextField();
		fldUsername.setForeground(new Color(255, 140, 35));
		fldUsername.setBorder(BorderFactory.createLineBorder(new Color(160, 160, 160)));
		fldUsername.setBackground(new Color(20, 20, 20));
		fldUsername.setBounds(247, 160, 200, 30);
		frame.getContentPane().add(fldUsername);
		fldUsername.setColumns(10);
		
		fldPassword = new JPasswordField();
		fldPassword.setForeground(new Color(255, 140, 35));
		fldPassword.setBorder(BorderFactory.createLineBorder(new Color(160, 160, 160)));
		fldPassword.setBackground(new Color (20, 20, 20));
		fldPassword.setBounds(247, 204, 200, 30);
		frame.getContentPane().add(fldPassword);


		JCheckBox chckbxAdvisor = new JCheckBox("Advisor");
		chckbxAdvisor.setForeground(new Color(255, 140, 35));
		chckbxAdvisor.setBackground(new Color(20, 20, 20));
		chckbxAdvisor.setBounds(11, 295, 139, 29);
		frame.getContentPane().add(chckbxAdvisor);
		
		JButton btnNewButton = new JButton("Login");
		//When a user clicks the button "Login", do the following:
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!chckbxAdvisor.isSelected()) {
					readDatabase.verifyLoginStudent(fldUsername.getText(), fldPassword.getText(), frame);
				}
				else {
					readDatabase.verifyLoginAdvisor(fldUsername.getText(), fldPassword.getText(), frame);
				}
			}
		});
		btnNewButton.setBounds(247, 294, 200, 30);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Help");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Please contact support@syr.edu regarding your issue");
			}
		});
		btnNewButton_1.setBounds(604, 294, 75, 30);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblJadvising = new JLabel("JAdvising");
		lblJadvising.setForeground(new Color(255, 140, 35));
		lblJadvising.setFont(new Font("MV Boli", Font.BOLD, 30));
		lblJadvising.setBounds(265, 33, 155, 111);
		frame.getContentPane().add(lblJadvising);
	}
}
