package frames;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import data.readDatabase;
import data.sqliteConnection;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;

public class Login {
	private JFrame frame;
	private JTextField fldUsername;
	private JPasswordField fldPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
		sqliteConnection.accountConnector();
		sqliteConnection.courseConnector();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 700, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel.setBounds(160, 165, 79, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel_1.setBounds(160, 209, 79, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		fldUsername = new JTextField();
		fldUsername.setBounds(247, 160, 200, 30);
		frame.getContentPane().add(fldUsername);
		fldUsername.setColumns(10);
		
		fldPassword = new JPasswordField();
		fldPassword.setBounds(247, 204, 200, 30);
		frame.getContentPane().add(fldPassword);
		
		JRadioButton rdbtnAdvisor = new JRadioButton("Advisor");
		rdbtnAdvisor.setBounds(292, 301, 155, 29);
		frame.getContentPane().add(rdbtnAdvisor);

		JButton btnNewButton = new JButton("Login");
		//When a user clicks the button "Login", do the following:
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!rdbtnAdvisor.isSelected()) {
					readDatabase.verifyLoginStudent(fldUsername.getText(), fldPassword.getText(), frame);
				}
				else {
					readDatabase.verifyLoginAdvisor(fldUsername.getText(), fldPassword.getText(), frame);
				}
			}
		});
		btnNewButton.setBounds(247, 345, 200, 30);
		frame.getContentPane().add(btnNewButton);
	}
}
