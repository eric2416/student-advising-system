package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import classes.Courses;
import data.readDatabase;
import data.sqliteConnection;
import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class Catalog extends JFrame {

	private JPanel contentPane;
	public static JTable table;
	private JTextField fldID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Catalog frame = new Catalog();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Catalog() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(41, 158, 915, 350);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setEnabled(false);
		
		fldID = new JTextField();
		fldID.setBounds(602, 117, 100, 30);
		contentPane.add(fldID);
		fldID.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Enroll");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Courses.addClass(fldID.getText());
			}
		});
		btnNewButton_1.setBounds(717, 117, 200, 30);
		contentPane.add(btnNewButton_1);
		
		JLabel lblId = new JLabel("ID");
		lblId.setBounds(643, 94, 69, 20);
		contentPane.add(lblId);
		
		JLabel lblToDrop = new JLabel("* To drop a class, please contact advising at advising@syr.edu");
		lblToDrop.setBounds(261, 524, 451, 20);
		contentPane.add(lblToDrop);
		
		readDatabase.populateCourses();
	}
}
