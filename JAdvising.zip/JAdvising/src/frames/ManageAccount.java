package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import classes.StudentAccount;
import data.editDatabase;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;

public class ManageAccount extends JFrame {

	private JPanel contentPane;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageAccount frame = new ManageAccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageAccount() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsername.setBounds(15, 16, 964, 20);
		contentPane.add(lblUsername);
		
		JLabel lblMajor = new JLabel("Major");
		lblMajor.setHorizontalAlignment(SwingConstants.CENTER);
		lblMajor.setBounds(15, 90, 964, 20);
		contentPane.add(lblMajor);
		
		JLabel lblCredits = new JLabel("Credits");
		lblCredits.setHorizontalAlignment(SwingConstants.CENTER);
		lblCredits.setBounds(15, 179, 964, 20);
		contentPane.add(lblCredits);
		
		JLabel lblCompletedCourses = new JLabel("Completed Courses");
		lblCompletedCourses.setHorizontalAlignment(SwingConstants.CENTER);
		lblCompletedCourses.setBounds(15, 274, 964, 20);
		contentPane.add(lblCompletedCourses);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setBounds(15, 377, 964, 20);
		contentPane.add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setBounds(411, 413, 200, 30);
		contentPane.add(passwordField);
		
		JButton btnChange = new JButton("Change");
		btnChange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				editDatabase.changePassword(lblPassword.getText());
			}
		});
		btnChange.setBounds(411, 460, 200, 30);
		contentPane.add(btnChange);
		
		JLabel lblWorksJustCapitalizes = new JLabel("works, just capitalizes first letter");
		lblWorksJustCapitalizes.setHorizontalAlignment(SwingConstants.CENTER);
		lblWorksJustCapitalizes.setBounds(15, 506, 964, 20);
		contentPane.add(lblWorksJustCapitalizes);
		
		JLabel lblNewLabel = new JLabel(StudentAccount.username);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(15, 52, 964, 20);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(StudentAccount.major);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(15, 136, 964, 20);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel(String.valueOf(StudentAccount.credits));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(15, 221, 964, 20);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel(StudentAccount.taken[0]);
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(15, 310, 964, 20);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblTooLazyTo = new JLabel("too lazy to list all rn, ez tho");
		lblTooLazyTo.setBounds(636, 341, 281, 20);
		contentPane.add(lblTooLazyTo);
	}
}
