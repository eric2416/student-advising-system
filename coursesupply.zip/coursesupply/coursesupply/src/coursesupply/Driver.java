package coursesupply;

import java.sql.*;

public class Driver {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			// Get a connection to database
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Database", "root", "root");
			// Create a statement
			Statement myStmt = myConn.createStatement();
			// Execute SQL query
			ResultSet myRs = myStmt.executeQuery("select * from SyracuseCourses");
			// Process the result set
			while(myRs.next()) {
				System.out.println(myRs.getString("CourseID") + myRs.getString("Course") + myRs.getString("CourseFullName")+ myRs.getString("CourseDays") + myRs.getString("CourseTime"));
			}
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
	}
}